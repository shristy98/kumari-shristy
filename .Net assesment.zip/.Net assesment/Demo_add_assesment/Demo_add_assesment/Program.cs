﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_add_assesment
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 3, 6, 5 };

            int sum = 0;
            foreach (int item in array)
            {
                sum += item;
            }

            Console.WriteLine(sum);
        }
    }
}
