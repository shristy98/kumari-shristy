﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_permutations
{
    class Program
    {
        static void Main(int[] a, int cid)
        {
            if(cid==a.Length-1)
            {
                return;
            }
            for (int i = cid; i < a.Length; i++)
            {
                print(a, int, cid);
                swap(a, int, cid);
            }
        }
    }
}
