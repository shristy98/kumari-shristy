﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Matrix
{
    class Program
    {
        static void Main()
        {
            int[,] num1 = new int[3, 3];
            Console.WriteLine("Enter Array elements..");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine("Element({0},{1})- ", i, j);
                    num1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Array in Mtrix");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine("{0}", num1[i, j]);
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
