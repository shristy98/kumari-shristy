﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_checkUserName_Password
{
    class Program
    {
        static void Main(string[] args)
        {
            string user, pass;
            int count = 0;

            do
            {
                Console.Write("Enter username: ");
                user = Console.ReadLine();

                Console.Write("Enter password: ");
                pass = Console.ReadLine();

                count++;

            }
            while (((user != "user") || (pass != "password"))
                && (count != 3));

            if (count == 3)
                Console.Write("Login attemp fail!");
            else
                Console.Write("Password correct!");
        }
    }
}
